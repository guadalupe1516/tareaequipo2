echo "Ingrese el numero de linea de la tarea a eliminar:"
read numero_linea

sed -i "${numero_linea}d" tareasDiarias.txt

echo "La tarea ha sido eliminada correctamente."