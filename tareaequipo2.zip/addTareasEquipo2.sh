echo "ingrese una tarea:"
read tarea

echo "$tarea" >> tareasDiarias.txt

echo "La tarea ha sido agregada correctamente."
