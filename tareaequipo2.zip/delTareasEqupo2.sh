echo "ingrese la cantidad de a eliminar:"
read cantidad

num_lineas=$(wc -l < tareasDiarias.txt)

inicio=$((num_lineas - cantidad + 1))

sed -i "${inicio},\$d" tareasDiarias.txt

echo "se han eliminado las últimas $cantidad tareas correctamente."

